package pl.codegym.task.task13.task1319;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.InputStreamReader;

/* 
Zapisywanie do pliku z konsoli
*/

public class Solution {
    public static void main(String[] args) {
        // tutaj wpisz swój kod
    }
}
