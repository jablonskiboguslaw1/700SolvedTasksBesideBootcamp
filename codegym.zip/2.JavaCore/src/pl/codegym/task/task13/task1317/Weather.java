package pl.codegym.task.task13.task1317;

public interface Weather {
    String getWeatherType();
}
