package pl.codegym.task.task13.task1317;

public interface WeatherType {
    String CLOUDY = "pochmurnie";
    String FOGGY = "mgliście";
    String FREEZING = "zimno";

}
