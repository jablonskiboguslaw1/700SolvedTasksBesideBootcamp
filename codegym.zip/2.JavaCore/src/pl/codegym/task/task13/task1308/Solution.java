package pl.codegym.task.task13.task1308;

/* 
Hej, żyjesz?
*/

public class Solution {
    public static void main(String[] args) throws Exception {
    }

    public interface Person{

        boolean isAlive();
    }

    public interface Presentable extends Person{}


}