package com.codegym.task.task17.task1721;

import java.util.ArrayList;
import java.util.List;

/* 
Transactionality

*/

public class Solution {
    public static List<String> allLines = new ArrayList<>();
    public static List<String> linesForRemoval = new ArrayList<>();

    public static void main(String[] args) {
    }

    public void joinData() throws CorruptedDataException {

    }
}
