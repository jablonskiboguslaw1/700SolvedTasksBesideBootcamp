package com.codegym.task.task17.task1719;

public interface Bean {   // This is a marker interface
}
