package com.codegym.task.task20.task2024;

import java.util.LinkedList;
import java.util.List;

/* 
Introducing graphs

*/
public class Solution {
    int node;
    List<Solution> edges = new LinkedList<>();

    public static void main(String[] args) {

    }
}
