package com.codegym.task.task18.task1828;

/* 
Prices 2

*/

public class Solution {
    public static void main(String[] args) {

    }
}
