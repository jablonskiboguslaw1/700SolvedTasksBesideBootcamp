package com.codegym.task.task15.task1529;

public class Helicopter implements CanFly {
    @Override
    public void fly() {

    }
}
