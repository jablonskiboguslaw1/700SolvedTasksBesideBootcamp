package com.codegym.task.task15.task1529;

public class Plane implements CanFly {
    int numbersOfPassengers;

    public Plane(int numbersOfPassengers) {
        this.numbersOfPassengers = numbersOfPassengers;
    }

    @Override
    public void fly() {

    }
}
