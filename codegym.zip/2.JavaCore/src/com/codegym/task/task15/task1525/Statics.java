package com.codegym.task.task15.task1525;

public class Statics {
    public static String FILE_NAME = "C:\\Users\\Bogus\\Documents\\file1.txt"/* Add the path to your source file here */;
}
