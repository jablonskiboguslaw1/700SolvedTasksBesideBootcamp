package com.codegym.task.task15.task1523;

public class SubSolution extends Solution{

    public SubSolution() {
    }

    protected SubSolution(int a) {
        super(a);
    }

 SubSolution(int a, String b) {
        super(a, b);
    }
}
