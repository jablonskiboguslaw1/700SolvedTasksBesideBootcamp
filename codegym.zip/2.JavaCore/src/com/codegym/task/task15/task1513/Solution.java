package com.codegym.task.task15.task1513;

/* 
The simplest code: part 3

*/

public class Solution {
    public static void main(String[] args) {
    }

    public interface Runnable {

    }

    public class Machine  implements Runnable {

    }

    public class Car extends Machine  {

    }
}
