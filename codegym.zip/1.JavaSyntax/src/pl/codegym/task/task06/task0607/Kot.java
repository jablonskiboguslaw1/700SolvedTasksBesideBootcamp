package pl.codegym.task.task06.task0607;

/* 
Licznik klasy
*/

public class Kot {
    static int licznikKotow=0;
    //tutaj wpisz swój kod

    public Kot() {
        licznikKotow++;
    }

    public static void main(String[] args) {

    }
}
