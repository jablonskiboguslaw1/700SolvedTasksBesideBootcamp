package pl.codegym.task.task06.task0618;

/* 
PocalujMojBlyszczacyMetalowyTylnySilownik
*/

public class Solution {
    public static class PocalujMojBlyszczacyMetalowyTylnySilownik {

    }

    public static void main(String[] args) {
        PocalujMojBlyszczacyMetalowyTylnySilownik obj = new PocalujMojBlyszczacyMetalowyTylnySilownik();//tutaj wpisz swój kod
        System.out.println(obj);
    }
}
