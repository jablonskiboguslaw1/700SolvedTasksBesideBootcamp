package pl.codegym.task.task06.task0601;

/* 
Metoda finalize (obiektu) Kot
*/

public class Kot {
    //tutaj wpisz swój kod
    public static void main(String[] args) {

    }
    protected void finalize() throws Throwable{}
}
