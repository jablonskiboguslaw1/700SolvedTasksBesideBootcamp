package pl.codegym.task.task06.task0619;

/* 
Trzy statyczne zmienne imie
*/

public class Solution {
    public static String imie;

    public static class Kot {
        public static String imie;
    }

    public static class Pies {
        public static String imie;
    }

    public static void main(String[] args) {

    }
}
