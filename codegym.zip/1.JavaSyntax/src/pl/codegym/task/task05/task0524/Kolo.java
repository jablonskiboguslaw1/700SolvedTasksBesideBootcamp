package pl.codegym.task.task05.task0524;

/* 
Istota koła
*/

public class Kolo {

    public double x;
    public double y;
    public double r;

    public Kolo(double x, double y, double r) {
        this.x = x;
        this.y = y;
        this.r = r;
    }

    //tutaj wpisz swój kod
    public static void main(String[] args) {

    }
}
