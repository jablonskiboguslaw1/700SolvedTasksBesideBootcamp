package pl.codegym.task.task05.task0516;

/* 
Przyjaciół nie da się kupić
*/

public class Przyjaciel {
   private String imie;
   private int wiek;
   private char plec;

    public Przyjaciel(String imie) {
        this.imie = imie;
    }

    public Przyjaciel(String imie, int wiek) {
        this.imie = imie;
        this.wiek = wiek;
    }

    public Przyjaciel(String imie, int wiek, char plec) {
        this.imie = imie;
        this.wiek = wiek;
        this.plec = plec;
    }
    //tutaj wpisz swój kod

    public static void main(String[] args) {

    }
}
