package pl.codegym.task.task05.task0528;

/* 
Wyświetl dzisiejszą datę
*/

import java.util.Date;

public class Solution {
    public static void main(String[] args) {
        System.out.println(12+" "+15+" "+2019); //tutaj wpisz swój kod
    }
}
