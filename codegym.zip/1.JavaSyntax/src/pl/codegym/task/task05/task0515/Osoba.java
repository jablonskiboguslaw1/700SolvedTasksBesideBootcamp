package pl.codegym.task.task05.task0515;

/* 
Inicjalizowanie obiektów
*/

public class Osoba {

    String imie;
    char plec;
    int pieniadze;
    int waga;
    double rozmiar;

   public void inicjalizuj(String imie, int pieniadze, char plec,int waga, double rozmiar) {
        this.imie = imie;
        this.pieniadze = pieniadze;
        this.plec = plec;
        this.waga = waga;
        this.rozmiar = rozmiar;
    }

    public static void main(String[] args) {

    }
}
