package pl.codegym.task.task05.task0501;

/* 
Tworzenie kota
*/

public class Kot {
    private String imie;
    private int wiek;
    private int waga;
    private int sila;//tutaj wpisz swój kod

    public static void main(String[] args) {

    }
}
