package pl.codegym.task.task05.task0506;

/* 
Ludzie
*/

public class Osoba {
    private String imie;
    private int wiek;
    private String adres;
    private char plec;//tutaj wpisz swój kod

    public static void main(String[] args) {

    }
}
