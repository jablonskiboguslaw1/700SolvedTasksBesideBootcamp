package pl.codegym.task.task05.task0508;

/* 
Gettery i settery dla klasy Osoba
*/

public class Osoba {
    private String imie;
    private int wiek;
    private char plec;//tutaj wpisz swój kod

    public String getImie() {
        return imie;
    }

    public void setImie(String imie) {
        this.imie = imie;
    }

    public int getWiek() {
        return wiek;
    }

    public void setWiek(int wiek) {
        this.wiek = wiek;
    }

    public char getPlec() {
        return plec;
    }

    public void setPlec(char plec) {
        this.plec = plec;
    }

    public static void main(String[] args) {

    }
}
