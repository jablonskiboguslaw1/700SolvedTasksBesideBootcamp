package pl.codegym.task.task05.task0503;

/* 
Gettery i settery dla klasy Pies
*/

public class Pies {
    private String imie;
    private int wiek;

    public String getImie() {
        return imie;
    }

    public void setImie(String imie) {
        this.imie = imie;
    }

    public int getWiek() {
        return wiek;
    }

    public void setWiek(int wiek) {
        this.wiek = wiek;
    }
    //tutaj wpisz swój kod

    public static void main(String[] args) {

    }
}
