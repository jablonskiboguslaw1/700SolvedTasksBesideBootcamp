package pl.codegym.task.task07.task0723;

/* 
Odliczanie
*/

public class Solution {
    public static void main(String[] args) throws InterruptedException {
        for (int i = 30; i >= 0; i--) {
            System.out.println(i);
            Thread.sleep(100);
            //tutaj wpisz swój kod
        }

        System.out.println("Bum!");
    }
}
