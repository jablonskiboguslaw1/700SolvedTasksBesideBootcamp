package pl.codegym.task.task07.task0707;

import java.util.ArrayList;

/* 
Co to za rodzaj listy?
*/

public class Solution {
    public static void main(String[] args) throws Exception {
       ArrayList<String> arr= new ArrayList<>() ;
      arr.add("gdsffs");
      arr.add("gaaaa");
      arr.add("aaaas");
      arr.add("asssss");
      arr.add("sssssss");

        System.out.println(arr.size());

        for (String str: arr)
            System.out.println(str);
              {

        }
    }
}
