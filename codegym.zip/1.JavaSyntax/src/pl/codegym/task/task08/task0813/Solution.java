package pl.codegym.task.task08.task0813;

import java.util.Set;
import java.util.HashSet;

/* 
20 wyrazów, które zaczynają się na literę „L”
*/

public class Solution {
    public static Set<String> utworzSet() {
     Set<String> str = new HashSet<>() ;
     str.add("Lala1");//tutaj wpisz swój kod
     str.add("Lala2");//tutaj wpisz swój kod
     str.add("Lala3");//tutaj wpisz swój kod
     str.add("Lala4");//tutaj wpisz swój kod
     str.add("Lala5");//tutaj wpisz swój kod
     str.add("Lala6");//tutaj wpisz swój kod
     str.add("Lala7");//tutaj wpisz swój kod
     str.add("Lala8");//tutaj wpisz swój kod
     str.add("Lala9");//tutaj wpisz swój kod
     str.add("Lala10");//tutaj wpisz swój kod
     str.add("Lala11");//tutaj wpisz swój kod
     str.add("Lala12");//tutaj wpisz swój kod
     str.add("Lala13");//tutaj wpisz swój kod
     str.add("Lala14");//tutaj wpisz swój kod
     str.add("Lala15");//tutaj wpisz swój kod
     str.add("Lala16");//tutaj wpisz swój kod
     str.add("Lala17");//tutaj wpisz swój kod
     str.add("Lala18");//tutaj wpisz swój kod
     str.add("Lala19");//tutaj wpisz swój kod
     str.add("Lala20");//tutaj wpisz swój kod
return str;
    }

    public static void main(String[] args) {

    }
}
