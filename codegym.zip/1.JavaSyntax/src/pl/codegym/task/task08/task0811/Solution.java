package pl.codegym.task.task08.task0811;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/* 
Kwartet metod
*/

public class Solution {
    public static List getListDlaGet() {
        return new ArrayList();//tutaj wpisz swój kod

    }

    public static List getListDlaSet() {
       return new ArrayList(); //tutaj wpisz swój kod

    }

    public static List getListDlaDodajLubWstaw() {
        return new LinkedList();//tutaj wpisz swój kod

    }

    public static List getListDlaUsun() {
        return new LinkedList();//tutaj wpisz swój kod

    }

    public static void main(String[] args) {

    }
}
