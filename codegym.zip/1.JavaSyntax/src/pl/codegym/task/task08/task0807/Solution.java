package pl.codegym.task.task08.task0807;

import java.util.*;

/* 
LinkedList i ArrayList
*/

public class Solution {
    public static Object utworzArrayList() {
       List lista = new ArrayList() ;//tutaj wpisz swój kod
return lista;
    }

    public static Object utworzLinkedList() {
      List linkedlista = new LinkedList();
      return linkedlista;//tutaj wpisz swój kod

    }

    public static void main(String[] args) {

    }
}
