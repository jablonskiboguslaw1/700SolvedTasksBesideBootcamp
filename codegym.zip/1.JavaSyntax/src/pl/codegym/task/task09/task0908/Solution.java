package pl.codegym.task.task09.task0908;

public class Solution {
    public static void main(String[] args) throws Exception {
        try{//tutaj wpisz swój kod

        String s = null;
        String m = s.toLowerCase();

        //tutaj wpisz swój kod
    }
        catch (NullPointerException e){
            System.out.println("NullPointerException");
        }
}}
