package pl.codegym.task.task09.task0910;

import java.util.ArrayList;

public class Solution {
    public static void main(String[] args) throws Exception {
       try{ //tutaj wpisz swój kod

        ArrayList<String> lista = new ArrayList<String>();
        String s = lista.get(18);

        //tutaj wpisz swój kod
    }catch(IndexOutOfBoundsException e){
           System.out.println("IndexOutOfBoundsException");
       }
}}