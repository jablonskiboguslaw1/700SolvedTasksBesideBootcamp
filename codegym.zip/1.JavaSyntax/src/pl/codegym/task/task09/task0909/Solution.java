package pl.codegym.task.task09.task0909;

public class Solution {
    public static void main(String[] args) throws Exception {
        try{//tutaj wpisz swój kod

        int[] m = new int[2];
        m[8] = 5;

        //tutaj wpisz swój kod
    }catch (ArrayIndexOutOfBoundsException e){
            System.out.println("ArrayIndexOutOfBoundsException");
        }
}}
