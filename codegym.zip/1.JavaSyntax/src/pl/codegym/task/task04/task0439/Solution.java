package pl.codegym.task.task04.task0439;

/* 
Łańcuszek
*/

import java.io.*;
import java.util.Scanner;

public class Solution {
    public static void main(String[] args) throws Exception {
       Scanner keyboard = new Scanner(System.in);
       String imie = keyboard.nextLine();
       for (int i = 1; i<=10; i++)
           System.out.println(imie+" mnie kocha.");//tutaj wpisz swój kod

    }
}
