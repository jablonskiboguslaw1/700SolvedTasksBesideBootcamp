package pl.codegym.task.task04.task0430;

/* 
Od 1 do 10
*/

import java.io.*;

public class Solution {
    public static void main(String[] args) throws Exception {
       int a = 1;
        while ( a<=10){
            System.out.println(a);//tutaj wpisz swój kod
a++;
    }
}}