package pl.codegym.task.task04.task0442;


/* 
Dodawanie
*/

import java.io.*;
import java.util.Scanner;

public class Solution {
    public static void main(String[] args) throws Exception {
        Scanner keyboard = new Scanner(System.in);
        int sum=0;

        for (int a= 0; a!=(-1);){
            a=keyboard.nextInt();
            sum+=a;}
        System.out.println(sum);//tutaj wpisz swój kod
    }
}
