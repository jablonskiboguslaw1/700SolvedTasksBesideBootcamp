package pl.codegym.task.task04.task0405;

/* 
Ustalanie liczby kotów
*/

public class Kot {
    private static int licznikKotow = 0;

    public static void setLicznikKotow(int licznikKotow) {
        Kot.licznikKotow = licznikKotow;//tutaj wpisz swój kod
    }

    public static void main(String[] args) {

    }
}
