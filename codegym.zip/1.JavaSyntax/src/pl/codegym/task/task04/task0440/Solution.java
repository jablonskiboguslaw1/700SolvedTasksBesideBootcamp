package pl.codegym.task.task04.task0440;

/* 
Uczciwe zarobki
*/

public class Solution {
    public static void main(String[] args) {
        String str = "Nie pytałem o dodatek na waciki. Amigo";
        for ( int i = 1; i <=100;i++)
            System.out.println(str);//tutaj wpisz swój kod
    }
}
