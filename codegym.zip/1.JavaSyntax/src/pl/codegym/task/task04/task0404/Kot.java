package pl.codegym.task.task04.task0404;

/* 
Rejestr kota
*/

public class Kot {
    private static int licznikKotow = 0;

    public static void dodajNowegoKota() {
       Kot.licznikKotow++;//tutaj wpisz swój kod
    }

    public static void main(String[] args) {

    }
}
