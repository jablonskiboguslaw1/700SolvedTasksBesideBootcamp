package pl.codegym.task.task04.task0438;

/* 
Rysowanie linii
*/

public class Solution {
    public static void main(String[] args) throws Exception {
       for (int i = 1; i<=10;i++)
           System.out.print(8);
       for (int j = 1; j<=10;j++)
            System.out.println(8);//tutaj wpisz swój kod

    }
}
