package pl.codegym.task.task04.task0424;

/* 
Trzy liczby
*/

import java.io.*;
import java.util.Scanner;

public class Solution {
    public static void main(String[] args) throws Exception {
       Scanner keyboard = new Scanner(System.in);
       int a = keyboard.nextInt();
       int b = keyboard.nextInt();
       int c = keyboard.nextInt();
if (!(a==b && b==c)){
       if (a==b) System.out.println(3);//tutaj wpisz swój kod
       if (a==c) System.out.println(2);//tutaj wpisz swój kod
       if (b==c) System.out.println(1);//tutaj wpisz swój kod
    }}
}
