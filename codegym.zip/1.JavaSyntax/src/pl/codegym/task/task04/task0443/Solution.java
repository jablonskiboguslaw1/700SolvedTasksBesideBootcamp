package pl.codegym.task.task04.task0443;


/* 
Imię to imię
*/

import java.io.*;
import java.util.Scanner;

public class Solution {
    public static void main(String[] args) throws Exception {
       Scanner keyboard = new Scanner(System.in);
       String imię = keyboard.nextLine();
       int rrrr= keyboard.nextInt();
       int mm= keyboard.nextInt();
       int dd= keyboard.nextInt();
        System.out.println("Mam na imię "+imię+".");
        System.out.println("Urodziłem/am się "+mm+"/"+dd+"/"+rrrr);
       //tutaj wpisz swój kod
    }
}
