package pl.codegym.task.task04.task0432;



/* 
Dobrego nigdy zbyt wiele
*/

import java.io.*;
import java.util.Scanner;

public class Solution {
    public static void main(String[] args) throws Exception {
       Scanner keyboard = new Scanner(System.in);
       String str = keyboard.nextLine();
       int n = keyboard.nextInt();
       int a =1;
       while (a<=n)
       {
           System.out.println(str);
           a++;//tutaj wpisz swój kod
       }

    }
}
