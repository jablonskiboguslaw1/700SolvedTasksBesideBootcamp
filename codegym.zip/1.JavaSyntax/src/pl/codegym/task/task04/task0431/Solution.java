package pl.codegym.task.task04.task0431;

/* 
Od 10 do 1
*/

import java.io.*;

public class Solution {
    public static void main(String[] args) throws Exception {
        int a = 10;
        while ( a>=1){
            System.out.println(a);//tutaj wpisz swój kod
            a--;  //tutaj wpisz swój kod

    }
}}
