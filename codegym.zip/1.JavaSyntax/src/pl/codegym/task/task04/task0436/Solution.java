package pl.codegym.task.task04.task0436;


/* 
Rysowanie prostokąta
*/

import java.io.*;
import java.util.Scanner;

public class Solution {
    public static void main(String[] args) throws Exception {
       Scanner keyboard = new Scanner(System.in);
       int m = keyboard.nextInt();//tutaj wpisz swój kod
       int n = keyboard.nextInt();//tutaj wpisz swój kod
for (int i = 1; i<=m;i++){
    for(int j = 1; j<=n; j++)
        System.out.print(8);
    System.out.println();
    }}
}
