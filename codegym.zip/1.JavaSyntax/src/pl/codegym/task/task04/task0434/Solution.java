package pl.codegym.task.task04.task0434;


/* 
Tabliczka mnożenia
*/

import java.io.*;

public class Solution {
    public static void main(String[] args) throws Exception {
        int a = 1;
        int b = 1;
        while(b<=10) {
            while (a <= 10) {
                System.out.print(a*b+" ");
                a++;
            }
            System.out.println();
            a=1;
            b++;  //tutaj wpisz swój kod

    }
}}
