package pl.codegym.task.task04.task0406;

/* 
Rejestr imion
*/

public class Kot {
    private String imieInazwisko;

    public void setImie(String imie, String nazwisko) {
        String imieInazwisko = imie + " " + nazwisko;
this.imieInazwisko = imieInazwisko;
        //tutaj wpisz swój kod
    }

    public static void main(String[] args) {

    }
}
