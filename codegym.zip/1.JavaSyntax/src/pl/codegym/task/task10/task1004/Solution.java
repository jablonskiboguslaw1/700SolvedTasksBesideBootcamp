package pl.codegym.task.task10.task1004;

/* 
Zadanie nr 4 z konwersją typu int
*/

public class Solution {
    public static void main(String[] args) {
        short liczba = 9;
        char zero = '0';
        int dziewiec = (zero + liczba);
        System.out.println((char)dziewiec);
    }
}
