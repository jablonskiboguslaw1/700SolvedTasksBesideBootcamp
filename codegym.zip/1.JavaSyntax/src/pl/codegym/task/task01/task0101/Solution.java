package pl.codegym.task.task01.task0101;

/* 
Tak sobie myślę, że bycie programistą jest cool
*/

public class Solution {
    public static void main(String[] args) {
        //tutaj wpisz swój kod
    }
}
