package pl.codegym.task.task01.task0133;

/* 
Nie myśl o sekundach...
*/

public class Solution {
    public static void main(String[] args) {
        int sekundyPo15 = 0;
        sekundyPo15+= (60*30);
        System.out.println(sekundyPo15);
    }
}