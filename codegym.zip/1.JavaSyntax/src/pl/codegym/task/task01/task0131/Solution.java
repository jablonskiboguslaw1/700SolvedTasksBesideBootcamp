package pl.codegym.task.task01.task0131;

/* 
Więcej konwersji
*/

public class Solution {
    public static void main(String[] args) {
        System.out.println(getStopyZCali(28));
    }

    public static int getStopyZCali(int cale) {
        return cale/12;//tutaj wpisz swój kod
    }
}