package pl.codegym.task.task03.task0322;


/* 
Głęboka i czysta miłość
*/

import java.io.*;

public class Solution {
    public static void main(String[] args) throws Exception {

      BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
      String imie1 = reader.readLine();//tutaj wpisz swój kod
      String imie2 = reader.readLine();//tutaj wpisz swój kod
      String imie3 = reader.readLine();//tutaj wpisz swój kod
        System.out.println(imie1+" + "+imie2+" + "+imie3 +" = Czysta miłość. Ooo la la!");
    }
}