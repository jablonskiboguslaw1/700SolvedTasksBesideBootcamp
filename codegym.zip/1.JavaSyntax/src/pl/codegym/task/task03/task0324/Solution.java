package pl.codegym.task.task03.task0324;

/* 
Cele biznesowe
*/

public class Solution {
    public static void main(String[] args) {
        System.out.println("Oczekuję wysokiej pensji, dlatego uczę się Javy");//tutaj wpisz swój kod
        System.out.println("Oczekuję wysokiej pensji, dlatego uczę się Javy");//tutaj wpisz swój kod
        System.out.println("Oczekuję wysokiej pensji, dlatego uczę się Javy");//tutaj wpisz swój kod
        System.out.println("Oczekuję wysokiej pensji, dlatego uczę się Javy");//tutaj wpisz swój kod
        System.out.println("Oczekuję wysokiej pensji, dlatego uczę się Javy");//tutaj wpisz swój kod
        System.out.println("Oczekuję wysokiej pensji, dlatego uczę się Javy");//tutaj wpisz swój kod
        System.out.println("Oczekuję wysokiej pensji, dlatego uczę się Javy");//tutaj wpisz swój kod
        System.out.println("Oczekuję wysokiej pensji, dlatego uczę się Javy");//tutaj wpisz swój kod
        System.out.println("Oczekuję wysokiej pensji, dlatego uczę się Javy");//tutaj wpisz swój kod
        System.out.println("Oczekuję wysokiej pensji, dlatego uczę się Javy");//tutaj wpisz swój kod
    }
}
