package pl.codegym.task.task03.task0316;

/* 
Eskejpowanie znaków
*/

public class Solution {
    public static void main(String[] args) {
        System.out.println("To jest ścieżka Windows: \"C:\\Program Files\\Java\\jdk1.8.0_172\\bin\"");
        System.out.println("To jest string Java: \\\"C:\\\\Program Files\\\\Java\\\\jdk1.8.0_172\\\\bin\\\"");//tutaj wpisz swój kod
    }
}
