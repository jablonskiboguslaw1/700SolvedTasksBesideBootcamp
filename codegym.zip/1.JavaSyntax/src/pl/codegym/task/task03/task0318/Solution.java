package pl.codegym.task.task03.task0318;

/* 
Plan podboju świata
*/

import java.io.*;

public class Solution {
    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        String sAge = reader.readLine();
        String imie = reader.readLine();

        int age = Integer.parseInt(sAge);


        System.out.println(imie+" przejmie władzę nad światem za "+age+" lat. Mua ha ha!");

        //tutaj wpisz swój kod
    }
}
