package pl.codegym.task.task03.task0320;


/* 
Skromny programista
*/

import java.io.*;

public class Solution {
    public static void main(String[] args) throws Exception {
      InputStream in;
      BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
      String imie = reader.readLine();
        System.out.println(imie+" zarabia 120 000 zł na rok. Ha ha ha!");//tutaj wpisz swój kod
    }
}
