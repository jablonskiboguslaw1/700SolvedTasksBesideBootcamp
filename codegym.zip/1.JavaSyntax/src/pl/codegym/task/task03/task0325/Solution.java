package pl.codegym.task.task03.task0325;

import java.io.*;

/* 
Oczekiwania finansowe
*/

public class Solution {
    public static void main(String[] args) throws Exception {

       BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
       String sn= reader.readLine()
;       int n =Integer.parseInt(sn);
        System.out.println("Zarobię "+ n +" zł na godzinę");
//tutaj wpisz swój kod
    }
}
